﻿function send() {
    var testname = $("#testname").val();
    //$.getJSON({
    //    url: "IndexHandler.ashx",
    //    data: { testname: testname }
    //    //success: function (data) {
    //    //    $("#testno").empty();
    //    //    $.each(data, function (i) {
    //    //        $("#testno").append("<option value='" + data[i][0] + "'>" + data[i][1] + "</option>");
    //    //    });
    //    //}
    //});
$.getJSON('IndexHandler.ashx', {
    testname: $("#testname").val()
    }).done(function (data) {
        //$("#testno").empty();
        $.each(data, function (i) {
            var option = "<option value='" + data[i][0] + "'>" + data[i][1] + "</option>"; 
            $("#testno").append(option);
        });
    });
} 

$("#testname").change(function () {
    send();
});