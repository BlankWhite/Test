﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using linq;

namespace ajaxTest
{
    /// <summary>
    /// IndexHandler 的摘要说明
    /// </summary>
    public class IndexHandler : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            //context.Response.Write("Hello World");
            context.Response.Write(GetTestNo(context));
        }

        public string GetTestNo(HttpContext context)
        {
            var res = "[[\"\",\"--請選擇--\"],";
            var testname = context.Request["testname"];
            var ctx = new TestDataClassesDataContext();
            var list = ctx.ajaxTest.Where(c => c.TestName == testname);
            foreach (var q in list)
            {
                res += "[\"" + q.TestNo + "\",\"" + q.TestNo + "\"],";
            }
            res = res.Substring(0, res.Length - 1);
            res += "]";
            return res;

        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}